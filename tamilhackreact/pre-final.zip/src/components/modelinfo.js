import { Link } from 'react-router-dom';
import logo from"./logo.png" 
import React, { useState,useEffect } from 'react'
import {useRef} from 'react';
import { Translate } from './Translate'
import "./modelinfo.css"

const Modelinfo = () => {

  

    const[headref,isheadref] = useHover()
    const[lungref,islungref] = useHover()
    const[abref,isabref] = useHover()
    const[pelref,ispelref] = useHover()
    const[legref,islegref] = useHover()

    
  return (
    <div className='modelmain'>
          <div className='navbar'>
            <p><img src={logo} width="200" height="50"></img></p>
    <p><Link to="/" id="link">
                HOME
            </Link></p>
    <p><Link to="/search" id="link">
                SEARCH DISEASE
            </Link></p>
            <p><Link to="/model" id="link">
                MODEL VIEW
            </Link></p>
    <p><Link to="/info" id="link">
                ORGAN VIEW
            </Link></p>
    <p><Link to="/news" id="link">
                NEWS
            </Link></p>
    </div>
    <div className='modelbody'>
        <div className='model_img'>

        </div>
        <div className='model_grid'>
            <div className='headr'  ref={headref}></div>
            <div className='lungr'  ref={lungref}></div>
            <div className='abdomr' ref={abref}></div>
            <div className='pelvicr' ref={pelref}></div>
            <div className='legr'    ref={legref}></div>
        </div>
        <div className='model_cont'>
            <div>{isheadref ? <div className='headr_cont'>
                <div className='headr_top'>
                    <div className='headr_img'>
                        <img src="https://i5.walmartimages.com/asr/2c36607a-3ce3-413a-81de-2cb46516e625.026a21daf915f51d92740c5a92fe5694.jpeg"></img>
                    </div>
                    <div className='headr_text'>
                        <h2><Translate text="HEAD REGION"/></h2>
                        <p><b>PARTS:</b><Translate text="Skull,Nose and nasal cavity,Eye,Ear,Mouth,Tooth,Neck"/></p>

                    </div>
                

                </div>
                <div className='headr_txt'>

                </div>
                <div>
                <div className='headr_lower'>
                        <div className='headr_lower_cont'>
                            <p>மூளை, மண்டை ஓடு மற்றும் தலை
                                        1. செல்லா துர்சிகா மற்றும் பாராசெல்லர் பிராந்தியத்தின் நோய்கள்
                                        2. ஹைட்ரோகெபாலஸ் மற்றும் CSF கோளாறுகள்
                                        3. ஸ்ட்ரோக் மற்றும் ஸ்ட்ரோக் மிமிக்ஸ்: நோய் கண்டறிதல் மற்றும் சிகிச்சை
                                        4. பெருமூளை நியோபிளாம்கள்
                                        5. நொன்ட்ராமாடிக் இன்ட்ராக்ரானியல் ஹெமரேஜ்
                                        6. இன்ட்ராக்ரானியல் தொற்று மற்றும் அழற்சி
                                        7. அதிர்ச்சிகரமான நரம்பியல் அவசரநிலை: அதிர்ச்சிகரமான மூளைக் காயம் உள்ள நோயாளிகளின் இமேஜிங்-ஒரு அறிமுகம்
                                        8. இன்ட்ராக்ரானியல் வெகுஜனங்களின் வேறுபட்ட நோயறிதல்
                                        9. நச்சு மற்றும் வளர்சிதை மாற்றக் கோளாறுகள்: வளர்சிதை மாற்ற நோய்கள்
                                        10. வலிப்பு நோயாளியை இமேஜிங் செய்தல்
                                        11. டிமென்ஷியாவில் நியூரோஇமேஜிங்
                                        12. மண்டை நரம்பு கோளாறுகள் உள்ள நோயாளிகளின் இமேஜிங் மதிப்பீடு</p>
                        </div>
                        
                    </div>

                </div>
            </div> :null}</div>
            <div>{islungref ? <div className='headr_cont'>
                <div className='headr_top'>
                    <div className='headr_img'>
                        <img src="https://s3-us-west-2.amazonaws.com/courses-images-archive-read-only/wp-content/uploads/sites/403/2015/04/21031647/2313_The_Lung_Pleurea.jpg"></img>
                    </div>
                    <div className='headr_text'>
                        <h2><Translate text="LUNG REGION"/></h2>
                        <p><b>PARTS:</b><Translate text="LUNGS,HEART"/></p>

                    </div>
                

                </div>
                <div className='headr_txt'>

                </div>
                <div>
                <div className='headr_lower'>
                        <div className='headr_lower_cont'>
                            <p>ஆஸ்துமா.
நுரையீரலின் ஒரு பகுதி அல்லது முழுவதுமாகச் சரிவு (நிமோதோராக்ஸ் அல்லது அட்லெக்டாசிஸ்)
நுரையீரலுக்கு காற்றைக் கொண்டு செல்லும் முக்கியப் பாதைகளில் (மூச்சுக்குழாய்கள்) வீக்கம் மற்றும் வீக்கம் (மூச்சுக்குழாய் அழற்சி)
சிஓபிடி.
நுரையீரல் புற்றுநோய்.
நுரையீரல் தொற்று (நிமோனியா)
நுரையீரலில் அசாதாரணமாக திரவம் குவிதல்</p>
                        </div>
                        
                    </div>

                </div>
            </div> : null}</div>
            <div>{isabref ? <div className='headr_cont'>
                <div className='headr_top'>
                    <div className='headr_img'>
                        <img src="https://www.registerednursern.com/wp-content/uploads/2019/05/nine-abdominal-regions-RN.jpg"></img>
                    </div>
                    <div className='headr_text'>
                        <h2>வயிற்றுப் பகுதி</h2>
                        <p><b>PARTS:</b><Translate text="Stomach,pancreas,liver,intestine"/></p>

                    </div>
                

                </div>
                <div className='headr_txt'>

                </div>
                <div>
                <div className='headr_lower'>
                        <div className='headr_lower_cont'>
                            <p>இரைப்பை அழற்சி. இரைப்பை அழற்சி என்பது வயிற்றின் புறணி வீக்கமடைவது அல்லது வீக்கமடைவது. ...
    இரைப்பை குடல் அழற்சி. இரைப்பை குடல் அழற்சி என்பது வயிறு மற்றும் சிறுகுடல் இரண்டிலும் ஏற்படும் அழற்சியாகும். ...
    காஸ்ட்ரோபரேசிஸ். ...
    அல்சர் டிஸ்ஸ்பெசியா. ...
    பெப்டிக் அல்சர். ...
    வயிறு (இரைப்பை) புற்றுநோய்.</p>
                        </div>
                        
                    </div>

                </div>
            </div>  : null}</div>
            <div>{ispelref ? <div className='headr_cont'>
                <div className='headr_top'>
                    <div className='headr_img'>
                        <img src="https://media.istockphoto.com/id/1143316411/vector/human-pelvis-anatomy-3d-medical-vector-illustration-on-white-background.jpg?s=170667a&w=is&k=20&c=-bQzSz6dMWbQZcGoL9AI0zNlgIvSXt-NN-Zx8mGf_lo="></img>
                    </div>
                    <div className='headr_text'>
                        <h2>இடுப்பு மண்டலம்</h2>
                        <p><b>PARTS:</b> டக்டஸ் டிஃபெரன்ஸ், செமினல் வெசிகல்ஸ், விந்துதள்ளல் குழாய்கள் மற்றும் புரோஸ்டேட்,எண்டோமெட்ரியம்,
    கருப்பை,
    கருப்பைகள்
    ஃபலோபியன் குழாய்கள்
    கருப்பை வாய்
    பிறப்புறுப்பு
    வுல்வா</p>

                    </div>
                

                </div>
                <div className='headr_txt'>

                </div>
                <div>
                <div className='headr_lower'>
                        <div className='headr_lower_cont'>
                            <p>மனித பாப்பிலோமா வைரஸ் (HPV)
    மைக்கோபிளாஸ்மா பிறப்புறுப்பு (Mgen)
    இடுப்பு அழற்சி நோய் (PID)
    STDகள் & மலட்டுத்தன்மை.
    கர்ப்ப காலத்தில் STDகள்.
    சிபிலிஸ்.
    டிரிகோமோனியாசிஸ்.
    பிற STDகள்.</p>
                        </div>
                        
                    </div>

                </div>
            </div>  : null}</div>
            <div>{islegref ? <div className='headr_cont'>
                <div className='headr_top'>
                    <div className='headr_img'>
                        <img src="https://o.quizlet.com/5Q6A7IJ-wUPww0MmuZcsKA.png"></img>
                    </div>
                    <div className='headr_text'>
                        <h2>கால் பகுதி</h2>
                        <p><b>PARTS:</b><Translate text="knees,femur,foot,joints,toes"/></p>

                    </div>
                

                </div>
                <div className='headr_txt'>

                </div>
                <div>
                <div className='headr_lower'>
                        <div className='headr_lower_cont'>
                            <p>எலும்பு முறிவு. இது எலும்பு முறிவுக்கான மருத்துவப் பெயர். ...
    இடப்பெயர்வு. ஒரு எலும்பை அதன் மூட்டில் இருந்து வெளியே இழுக்கும்போது இது நிகழ்கிறது. ...
    சுளுக்கு. சுளுக்கு என்பது தசைநார்களின் நீட்சி மற்றும் கண்ணீர். ...
    விகாரங்கள். ...
    தசை அதிகப்படியான பயன்பாடு. ...
    ஒரு நேரடி அடியிலிருந்து தசை சிராய்ப்பு. ...
    ஒரு நேரடி அடியிலிருந்து எலும்பு காயம் (இடுப்பில் இருப்பது போல). ...
    தோல் காயம்.</p>
                        </div>
                        
                    </div>

                </div>
            </div>  : null}</div>

        </div>
    </div>
    </div>
  )
}

const useHover = () => {
    const [isHovering, setIsHovering] = React.useState(false);
  
    const handleMouseOver = React.useCallback(() => setIsHovering(true), []);
    const handleMouseOut = React.useCallback(() => setIsHovering(false), []);
  
    const nodeRef = React.useRef();
  
    const callbackRef = React.useCallback(
      node => {
        if (nodeRef.current) {
          nodeRef.current.removeEventListener('mouseover', handleMouseOver);
          nodeRef.current.removeEventListener('mouseout', handleMouseOut);
        }
  
        nodeRef.current = node;
  
        if (nodeRef.current) {
          nodeRef.current.addEventListener('mouseover', handleMouseOver);
          nodeRef.current.addEventListener('mouseout', handleMouseOut);
        }
      },
      [handleMouseOver, handleMouseOut]
    );
  
    return [callbackRef, isHovering];
  };

export default Modelinfo